package com.example.biobanddisplay

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class PpgActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // You can set up your UI here later, for example:
        // setContentView(R.layout.activity_ppg)
    }
}
